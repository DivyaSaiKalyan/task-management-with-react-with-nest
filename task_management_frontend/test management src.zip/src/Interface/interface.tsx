export interface Iprops {
  tasksName: string[];
  tasksMove: any;
  taskDisplay: string[];
  displayTask: any;
}

export interface Idata {
  id: number;
  task: string;
  status: number;
}
